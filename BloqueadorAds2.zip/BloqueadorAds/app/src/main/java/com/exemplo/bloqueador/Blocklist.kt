package com.exemplo.bloqueador

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Blocklist {

    // Listas públicas grandes de anúncios/rastreadores (formatos hosts, adblock e domínios puros)
    val SOURCES = listOf(
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt",
        "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/pro.txt",
        "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext"
    )

    private val DOMAIN = Regex("^[a-z0-9_.-]+\\.[a-z0-9-]{2,}$")

    @Volatile private var big: Set<String> = emptySet()
    @Volatile private var customBlock: Set<String> = emptySet()
    @Volatile private var customAllow: Set<String> = emptySet()

    val totalDomains: Int get() = big.size + customBlock.size

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("bloqueador", Context.MODE_PRIVATE)

    fun lastUpdate(ctx: Context): Long {
        val f = File(ctx.filesDir, "downloaded.txt")
        return if (f.exists()) f.lastModified() else 0L
    }

    fun parseLine(raw: String): String? {
        var l = raw.trim()
        if (l.isEmpty() || l[0] == '#' || l[0] == '!' || l[0] == '[') return null
        if (l.startsWith("@@")) return null
        val d: String
        if (l.startsWith("||")) {
            val end = l.indexOf('^')
            if (end < 0) return null
            d = l.substring(2, end)
        } else {
            val hash = l.indexOf('#')
            if (hash > 0) l = l.substring(0, hash).trim()
            val parts = l.split(Regex("\\s+"))
            d = when {
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                parts.size == 1 -> parts[0]
                else -> return null
            }
        }
        val x = d.lowercase().trimEnd('.')
        return if (DOMAIN.matches(x)) x else null
    }

    @Synchronized
    fun loadAll(ctx: Context) {
        val set = HashSet<String>(400000)
        ctx.assets.open("blocklist_base.txt").bufferedReader().useLines { lines ->
            lines.forEach { l -> parseLine(l)?.let { set.add(it) } }
        }
        val f = File(ctx.filesDir, "downloaded.txt")
        if (f.exists()) {
            f.bufferedReader().useLines { lines ->
                lines.forEach { l -> parseLine(l)?.let { set.add(it) } }
            }
        }
        big = set
        val p = prefs(ctx)
        customBlock = p.getStringSet("block", emptySet())!!.toSet()
        customAllow = p.getStringSet("allow", emptySet())!!.toSet()
    }

    fun update(ctx: Context, progress: (String) -> Unit) {
        val set = HashSet<String>(500000)
        var ok = 0
        for ((i, url) in SOURCES.withIndex()) {
            progress("Baixando lista ${i + 1}/${SOURCES.size}…")
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 40000
                c.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { l -> parseLine(l)?.let { set.add(it) } }
                }
                c.disconnect()
                ok++
            } catch (e: Exception) {
                // segue para a próxima lista
            }
        }
        if (ok == 0 || set.size < 1000) {
            progress("Falha ao baixar as listas. Verifique a internet.")
            return
        }
        val tmp = File(ctx.filesDir, "downloaded.tmp")
        tmp.bufferedWriter().use { w ->
            set.forEach { w.write(it); w.write("\n") }
        }
        tmp.renameTo(File(ctx.filesDir, "downloaded.txt"))
        loadAll(ctx)
        progress("Pronto: $totalDomains domínios na lista ($ok de ${SOURCES.size} fontes).")
    }

    fun normalize(input: String): String? {
        val s = input.trim().lowercase()
            .removePrefix("http://").removePrefix("https://")
            .substringBefore('/').substringBefore(':').trimEnd('.')
        return if (DOMAIN.matches(s)) s else null
    }

    fun setCustom(ctx: Context, domain: String, block: Boolean) {
        val b = HashSet(customBlock)
        val a = HashSet(customAllow)
        if (block) { b.add(domain); a.remove(domain) } else { a.add(domain); b.remove(domain) }
        prefs(ctx).edit().putStringSet("block", b).putStringSet("allow", a).apply()
        customBlock = b
        customAllow = a
    }

    private fun matches(set: Set<String>, domain: String): Boolean {
        var s = domain
        while (true) {
            if (set.contains(s)) return true
            val i = s.indexOf('.')
            if (i < 0) return false
            s = s.substring(i + 1)
        }
    }

    fun isBlocked(name: String): Boolean {
        val d = name.lowercase().trimEnd('.')
        if (matches(customAllow, d)) return false
        if (matches(customBlock, d)) return true
        return matches(big, d)
    }
}
