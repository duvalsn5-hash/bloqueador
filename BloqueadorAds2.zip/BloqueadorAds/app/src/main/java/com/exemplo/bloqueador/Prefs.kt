package com.exemplo.bloqueador

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("bloqueador", Context.MODE_PRIVATE)

    fun autostart(c: Context): Boolean = p(c).getBoolean("autostart", false)
    fun setAutostart(c: Context, v: Boolean) { p(c).edit().putBoolean("autostart", v).apply() }

    fun weekly(c: Context): Boolean = p(c).getBoolean("weekly", true)
    fun setWeekly(c: Context, v: Boolean) { p(c).edit().putBoolean("weekly", v).apply() }

    fun excluded(c: Context): Set<String> = p(c).getStringSet("excluded", emptySet())!!.toSet()
    fun setExcluded(c: Context, s: Set<String>) { p(c).edit().putStringSet("excluded", HashSet(s)).apply() }
}
