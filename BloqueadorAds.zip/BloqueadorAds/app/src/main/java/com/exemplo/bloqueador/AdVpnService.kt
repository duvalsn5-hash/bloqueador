package com.exemplo.bloqueador

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * VPN local: só o tráfego DNS (para 10.111.222.2) entra no túnel.
 * Consultas de domínios de anúncios recebem 0.0.0.0 / ::, as demais são
 * encaminhadas ao DNS real (1.1.1.1, com 8.8.8.8 de reserva).
 */
class AdVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.exemplo.bloqueador.START"
        const val ACTION_STOP = "com.exemplo.bloqueador.STOP"
        const val VPN_ADDRESS = "10.111.222.1"
        const val VPN_DNS = "10.111.222.2"
        val UPSTREAMS = listOf("1.1.1.1", "8.8.8.8")

        @Volatile var running = false
        val blockedCount = AtomicInteger(0)
        val allowedCount = AtomicInteger(0)
    }

    private class Question(val name: String, val end: Int, val type: Int)

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool = Executors.newFixedThreadPool(16)
    @Volatile private var out: FileOutputStream? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun startVpn() {
        if (running) return
        running = true
        worker = Thread {
            try {
                Blocklist.loadAll(applicationContext)
                val pfd = Builder()
                    .setSession("Bloqueador de Anúncios")
                    .setMtu(1500)
                    .addAddress(VPN_ADDRESS, 24)
                    .addDnsServer(VPN_DNS)
                    .addRoute(VPN_DNS, 32)
                    .establish()
                if (pfd == null) {
                    running = false
                    return@Thread
                }
                tun = pfd
                val input = FileInputStream(pfd.fileDescriptor)
                out = FileOutputStream(pfd.fileDescriptor)
                val buf = ByteArray(32767)
                while (running) {
                    val n = input.read(buf)
                    if (n > 0) handlePacket(buf.copyOf(n)) else Thread.sleep(5)
                }
            } catch (e: Exception) {
                // encerra
            } finally {
                closeTun()
                running = false
            }
        }.also { it.start() }
    }

    private fun stopVpn() {
        running = false
        closeTun()
    }

    private fun closeTun() {
        try { tun?.close() } catch (e: Exception) {}
        tun = null
    }

    // ---------- Pacotes ----------

    private fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun handlePacket(p: ByteArray) {
        if (p.size < 28) return
        if ((p[0].toInt() shr 4) != 4) return          // só IPv4
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p[9].toInt() != 17) return                  // só UDP
        val srcPort = u16(p, ihl)
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return
        val udpLen = u16(p, ihl + 4)
        val end = minOf(p.size, ihl + udpLen)
        if (end - (ihl + 8) < 12) return

        val dns = p.copyOfRange(ihl + 8, end)
        val srcIp = p.copyOfRange(12, 16)
        val dstIp = p.copyOfRange(16, 20)
        val q = parseQuestion(dns)

        if (q != null && Blocklist.isBlocked(q.name)) {
            blockedCount.incrementAndGet()
            reply(srcIp, dstIp, srcPort, dstPort, blockedResponse(dns, q))
        } else {
            pool.execute {
                val r = forward(dns)
                if (r != null) {
                    allowedCount.incrementAndGet()
                    reply(srcIp, dstIp, srcPort, dstPort, r)
                }
            }
        }
    }

    private fun parseQuestion(d: ByteArray): Question? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val len = d[i].toInt() and 0xFF
            if (len == 0) { i++; break }
            if ((len and 0xC0) != 0) return null
            if (i + 1 + len > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, len, Charsets.US_ASCII))
            i += 1 + len
        }
        if (i + 4 > d.size) return null
        return Question(sb.toString(), i + 4, u16(d, i))
    }

    private fun blockedResponse(d: ByteArray, q: Question): ByteArray {
        val answer: ByteArray? = when (q.type) {
            1 -> ByteArray(4)      // A    -> 0.0.0.0
            28 -> ByteArray(16)    // AAAA -> ::
            else -> null           // HTTPS/outros -> resposta vazia (sem erro)
        }
        val r = ByteArrayOutputStream()
        r.write(d, 0, 2)
        r.write(0x80 or (d[2].toInt() and 0x01))  // QR + RD
        r.write(0x80)                              // RA
        r.write(0); r.write(1)                     // 1 pergunta
        r.write(0); r.write(if (answer != null) 1 else 0)
        r.write(0); r.write(0); r.write(0); r.write(0)
        r.write(d, 12, q.end - 12)
        if (answer != null) {
            r.write(0xC0); r.write(0x0C)           // ponteiro para o nome
            r.write(0); r.write(q.type)
            r.write(0); r.write(1)                 // classe IN
            r.write(0); r.write(0); r.write(0); r.write(60)  // TTL
            r.write(0); r.write(answer.size)
            r.write(answer)
        }
        return r.toByteArray()
    }

    private fun forward(dns: ByteArray): ByteArray? {
        for (up in UPSTREAMS) {
            try {
                DatagramSocket().use { s ->
                    protect(s)  // evita que a consulta volte para o próprio túnel
                    s.soTimeout = 3000
                    s.connect(InetAddress.getByName(up), 53)
                    s.send(DatagramPacket(dns, dns.size))
                    val buf = ByteArray(4096)
                    val resp = DatagramPacket(buf, buf.size)
                    s.receive(resp)
                    return buf.copyOf(resp.length)
                }
            } catch (e: Exception) {
                // tenta o próximo DNS
            }
        }
        return null
    }

    private fun reply(srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray) {
        val pkt = buildUdpPacket(dstIp, srcIp, dstPort, srcPort, payload)
        synchronized(this) {
            try { out?.write(pkt) } catch (e: Exception) {}
        }
    }

    private fun buildUdpPacket(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val h = ByteArray(total)
        h[0] = 0x45
        h[2] = (total shr 8).toByte(); h[3] = total.toByte()
        h[6] = 0x40                       // DF
        h[8] = 64                         // TTL
        h[9] = 17                         // UDP
        System.arraycopy(src, 0, h, 12, 4)
        System.arraycopy(dst, 0, h, 16, 4)
        var sum = 0
        for (i in 0 until 20 step 2) sum += u16(h, i)
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val c = sum.inv() and 0xFFFF
        h[10] = (c shr 8).toByte(); h[11] = c.toByte()
        h[20] = (sp shr 8).toByte(); h[21] = sp.toByte()
        h[22] = (dp shr 8).toByte(); h[23] = dp.toByte()
        val ul = 8 + payload.size
        h[24] = (ul shr 8).toByte(); h[25] = ul.toByte()
        System.arraycopy(payload, 0, h, 28, payload.size)
        return h
    }
}
