package com.exemplo.bloqueador

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var info: TextView
    private lateinit var toggle: Button
    private lateinit var input: EditText

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun text(size: Float, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 2)
        }

        col.addView(text(24f, true).apply { this.text = "Bloqueador de Anúncios" })
        status = text(18f, true); col.addView(status)
        counter = text(15f); col.addView(counter)

        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        col.addView(toggle)

        col.addView(Button(this).apply {
            text = "Atualizar listas de bloqueio"
            setOnClickListener {
                info.text = "Iniciando…"
                Thread {
                    Blocklist.update(applicationContext) { m -> runOnUiThread { info.text = m } }
                }.start()
            }
        })

        col.addView(text(15f, true).apply { this.text = "Domínio personalizado" })
        input = EditText(this).apply {
            hint = "exemplo.com"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        col.addView(input)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(Button(this).apply {
            text = "Bloquear"
            setOnClickListener { applyCustom(true) }
        }, lp)
        row.addView(Button(this).apply {
            text = "Liberar"
            setOnClickListener { applyCustom(false) }
        }, lp)
        col.addView(row)

        info = text(14f).apply { setTextColor(Color.DKGRAY) }
        col.addView(info)

        col.addView(text(13f).apply {
            setTextColor(Color.GRAY)
            this.text = "Importante: no Chrome, desative \"Usar DNS seguro\" " +
                "(Configurações > Privacidade e segurança), senão ele ignora o bloqueio. " +
                "Em Configurações do Android > DNS privado, deixe em Automático ou Desativado."
        })

        setContentView(ScrollView(this).apply { addView(col) })

        Thread { Blocklist.loadAll(applicationContext) }.start()
    }

    private fun onToggle() {
        if (AdVpnService.running) {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) startActivityForResult(i, 1) else startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_START))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) startVpn()
    }

    private fun applyCustom(block: Boolean) {
        val d = Blocklist.normalize(input.text.toString())
        if (d == null) {
            Toast.makeText(this, "Domínio inválido", Toast.LENGTH_SHORT).show()
            return
        }
        Blocklist.setCustom(applicationContext, d, block)
        info.text = if (block) "$d (e subdomínios) será bloqueado." else "$d (e subdomínios) foi liberado."
        input.text.clear()
    }

    private fun refresh() {
        if (AdVpnService.running) {
            status.text = "● Proteção ATIVA"
            status.setTextColor(Color.rgb(0, 140, 60))
            toggle.text = "Desativar"
        } else {
            status.text = "○ Proteção desativada"
            status.setTextColor(Color.rgb(190, 40, 40))
            toggle.text = "Ativar"
        }
        counter.text = "Bloqueados: ${AdVpnService.blockedCount.get()}  ·  " +
            "Permitidos: ${AdVpnService.allowedCount.get()}\n" +
            "Domínios na lista: ${Blocklist.totalDomains}"
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
